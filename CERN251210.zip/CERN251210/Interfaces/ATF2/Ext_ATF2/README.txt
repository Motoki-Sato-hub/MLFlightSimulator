sed 's/WIRE/DRIFT/g' ATF2_EXT_FF_v5.2.twiss_v0 > ATF2_EXT_FF_v5.2.twiss
