import sys, os, pickle, re, matplotlib, glob, time,json
from datetime import datetime
import numpy as np
from PyQt6 import uic
from PyQt6.QtCore import Qt,QProcess,QProcessEnvironment
from PyQt6.QtWidgets import (QApplication, QRadioButton,QSizePolicy, QMainWindow, QFileDialog, QListWidget, QMessageBox,QProgressDialog, QVBoxLayout, QPushButton, QDialog, QLabel)
from State import State
matplotlib.use("QtAgg")
from enum import Enum
from dataclasses import dataclass
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from LogConsole_BBA import LogConsole
from SaveOrLoad_BBA import SaveOrLoad_BBA
from DFS_WFS_Correction_BBA import DFS_WFS_Correction_BBA
from ChangeBpmsWeights_BBA import ChangeBpmsWeights_BBA

import matplotlib.pyplot as plt


class Machine(Enum):
    ATF2_DR = "ATF2_DR"
    ATF2_EXT = "ATF2_Ext"
    ATF2_LINAC = "ATF2_Linac"
    ATF2_DR_RFT = "ATF2_DR_RFT"
    ATF2_EXT_RFT = "ATF2_Ext_RFT"

class MainWindow(QMainWindow, SaveOrLoad_BBA, DFS_WFS_Correction_BBA):
    def __init__(self, interface, dir_name):
        super().__init__()
        self.cwd = os.getcwd()
        self.interface = interface
        self.dir_name = dir_name
        self._cancel = False
        self._number_re = re.compile(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?")
        self.S = State(interface=self.interface)
        ui_path = os.path.join(os.path.dirname(__file__), "BBA_GUI.ui")
        uic.loadUi(ui_path, self)
        self._data_dirs = {"traj": None, "dfs": None, "wfs": None}
        self._hist_orbit, self._hist_disp,self._hist_wake=[],[],[]
        self._hist_orbit_x,self._hist_orbit_y = [],[]
        self._hist_disp_x,self._hist_disp_y = [],[]
        self._hist_wake_x,self._hist_wake_y = [],[]
        self.log_console=None
        self.show_response_matrix=None
        self._setup_canvases()
        self._populate_lists()
        self._procs=[]
        self.load_correctors_button.clicked.connect(self._load_correctors)
        self.load_bpms_button.clicked.connect(self._load_bpms)
        self.radio_buttons=[self.mode_orbit,self.mode_dispersion, self.mode_wakefield]
        self.pushButton_log.clicked.connect(self._show_console_log)
        self.session_database_3.setText(dir_name)
        if hasattr(self, "pushButton_8"):  # traj
            self.pushButton_8.clicked.connect(self._pick_and_load_traj_data)
        if hasattr(self, "pushButton_9"):  # dfs
            self.pushButton_9.clicked.connect(self._pick_and_load_disp_data)
        if hasattr(self, "pushButton_10"):  # wfs
            self.pushButton_10.clicked.connect(self._pick_and_load_wake_data)
        if hasattr(self, "clear_graphs_button"):
            self.clear_graphs_button.clicked.connect(self._clear_graphs)
        if hasattr(self, "pushButton_11"):
            self.pushButton_11.clicked.connect(self.load_session_settings)

        self.modes= [ 'Orbit', 'Dispersion', 'Wakefield']
        self._running = False
        self.appropriate_settings_energy=None
        self.appropriate_settings_intensity=None
        self.appropriate_settings_reset_e=None
        self.appropriate_settings_reset_ch=None
        interface_name=interface.get_name()
        self.start_button.clicked.connect(self._on_start_click)
        self.stop_button.clicked.connect(self._stop_correction)
        self.corrs = self.S.get_correctors()["names"]
        self.setWindowTitle("BBA_GUI")
        self.lineEdit.setText("1")
        self.lineEdit_2.setText("10")
        self.lineEdit_3.setText("10")
        self.lineEdit_4.setText("0.001")
        self.lineEdit_5.setText("10")
        self.lineEdit_6.setText("0.4")
        self.compute_response_matrix_button.clicked.connect(self._display_response_matrix)

        correctors = self.interface.get_correctors()
        correctors_list = correctors['names']

        max_curr_h=0.0
        max_curr_v=0.0

        if correctors_list is not None:
            hcorrs = self.interface.get_hcorrectors_names()
            vcorrs = self.interface.get_vcorrectors_names()
            hcorr_indexes = np.array([index for index, string in enumerate(correctors_list) if string in hcorrs])
            vcorr_indexes = np.array([index for index, string in enumerate(correctors_list) if string in vcorrs])

            def clean_array(a):
                a = np.array([0 if x is None else x for x in a], dtype=float)
                a[np.isnan(a)] = 0
                return a

            max_curr_h = 1.15 * np.max(np.abs(clean_array(np.array(correctors['bdes'])[hcorr_indexes])))
            max_curr_v = 1.15 * np.max(np.abs(clean_array(np.array(correctors['bdes'])[vcorr_indexes])))

        self.max_horizontal_current_spinbox.setValue(max_curr_h)
        self.max_horizontal_current_spinbox.setSingleStep(0.01)
        self.max_vertical_current_spinbox.setValue(max_curr_v)
        self.max_vertical_current_spinbox.setSingleStep(0.01)


    def _on_start_click(self):
        print("Starting button clicked...")
        self.log("Starting button clicked...")
        if not self._running:
            self._running = True
            self._step = True

            try:
                self._start_correction()
            finally:
                self._running = False
        else:
            self._step = True

    def _expand_data_path(self,path):
        home=os.path.expanduser("~")
        if path.startswith(home+os.sep): #the character used by the operating system to separate pathname components
            return "~"+path[len(home):]
        return path

    def _setup_canvases(self):
        if FigureCanvas is None:
            self.traj_canvas = self.disp_canvas = self.wake_canvas = None
            self.traj_ax=self.disp_ax = self.wake_ax = None
            return

        def install(host):
            fig = Figure(figsize=(5, 2.4), tight_layout=True)
            canvas = FigureCanvas(fig)
            layout = host.layout()
            if layout is None:
                from PyQt6.QtWidgets import QVBoxLayout
                layout = QVBoxLayout(host)
                layout.setContentsMargins(0, 0, 0, 0)
            layout.addWidget(canvas)
            ax = fig.add_subplot(111)
            return fig, canvas,ax

        self.traj_fig, self.traj_canvas, self.traj_ax = install(self.plot_widget_3)
        self.disp_fig, self.disp_canvas,self.disp_ax = install(self.plot_widget_4)
        self.wake_fig, self.wake_canvas, self.wake_ax = install(self.plot_widget_5)

    def _plot_series(self, ax, canvas, values_x,values_y, vals,title=None,ylabel="[mm]"):
        if canvas is None or ax is None:
            return
        ax.clear()
        if values_x:
            ax.plot(range(1, len(values_x) + 1), values_x, marker="o",color='red',label="x")
        if values_y:
            ax.plot(range(1, len(values_y) + 1), values_y, marker="o",color='blue',label="y")
        if vals:
            ax.plot(range(1, len(vals) + 1), vals, linestyle="dashed",color='black',label="combined norm")
        if values_x or values_y:
            ax.legend(fontsize=7)
        if title is not None:
            ax.set_title(title)
        ax.set_xlabel("Iteration", fontsize=8)
        if ylabel is not None:
            ax.set_ylabel(ylabel, fontsize=7)
        ax.tick_params(axis="both", which="major", labelsize=7)
        ax.yaxis.get_offset_text().set_fontsize(7)
        ax.grid(True, alpha=0.3)
        canvas.draw_idle()

    def _populate_lists(self):
        corrs = self.S.get_correctors()["names"]
        bpms = self.S.get_bpms()["names"]
        self.correctors_list.setSelectionMode(QListWidget.SelectionMode.ExtendedSelection)
        self.bpms_list.setSelectionMode(QListWidget.SelectionMode.ExtendedSelection)
        self.correctors_list.insertItems(0, corrs)
        self.bpms_list.insertItems(0, bpms)  # at the top of the list

    def _get_selection(self):
        corrs_all = self.S.get_correctors()["names"]
        bpms_all = self.S.get_bpms()["names"]
        corrs = [it.text() for it in self.correctors_list.selectedItems()] or corrs_all
        bpms = [it.text() for it in self.bpms_list.selectedItems()] or bpms_all
        return corrs, bpms

    def _force_triangular(self) -> bool:
        try:
            return bool(self.checkBox.isChecked())
        except Exception:
            return False

    def _with_progress(self, total, title):
        prog = QProgressDialog(title, "Cancel", 0, total, self)
        prog.setWindowModality(Qt.WindowModality.ApplicationModal)  # user cant interact with the main window
        prog.setMinimumDuration(0)

        def cb(i, n, text):
            prog.setMaximum(n)
            prog.setValue(i)
            prog.setLabelText(text)
            QApplication.processEvents()
            return not prog.wasCanceled()

        return prog, cb

    def _read_params(self):
        def getf(name, default):  # gets the text value and turns it into a float
            w = getattr(self, name, None)
            if w is None:
                return float(default)

            txt = (w.text() or "").strip()
            if txt:
                try:
                    return float(txt)
                except ValueError:
                    pass
            w.setText(f"{default:g}")
            return float(default)

        def geti(name, default):  # the same, but to an int
            w = getattr(self, name, None)
            if w is None:
                return int(default)

            txt = (w.text() or "").strip()
            if txt:
                try:
                    return int(float(txt))
                except ValueError:
                    pass
            w.setText(str(int(default)))
            return int(default)

        orbit_w = getf("lineEdit", 1.0)
        disp_w = getf("lineEdit_2", 10.0)
        wake_w = getf("lineEdit_3", 10.0)
        rcond = getf("lineEdit_4", 0.001)
        iters = geti("lineEdit_5", 10)
        gain = getf("lineEdit_6", 0.4)
        return orbit_w, disp_w, wake_w, rcond, iters, gain

    def _start_correction(self):
        try:
            print("Starting correction...")
            self.log("Starting correction...")
            self._cancel = False
            w1, w2, w3, rcond, iters, gain = self._read_params()
            wgt_orb, wgt_dfs, wgt_wfs = w1, w2, w3

            corrs, bpms = self._get_selection()

            Cx = [s for s in corrs if (s.lower().startswith('zh') or ("DHG" in s) or (s.lower().startswith('zx')))]
            Cy = [s for s in corrs if (s.lower().startswith('zv') or (("SDV" in s) or ("DHJ" in s)))]

            Axx, Ayy, B0x, B0y = self._creating_response_matrices()

            self.setWindowTitle("BBA_GUI - [Correction running]")

            target_disp_x, target_disp_y = self.interface.get_target_dispersion(bpms)

            max_curr_h = self.max_horizontal_current_spinbox.value() # gauss * m
            max_curr_v = self.max_vertical_current_spinbox.value() # gauss * m

            def clamp(val, max_val):
                if max_val == 0.0:
                    return val
                return max(-max_val, min(val, max_val))

            plt.ion()

            for it in range(iters):
                if self._cancel:
                    break
                self._step = False

                # nominal
                print("Measuring orbit")

                self.log("Measuring orbit")
                self.S.pull(self.interface)
                print('State::pull done')
                O0 = self.S.get_orbit(bpms)
                O0x = O0['x'].reshape(-1, 1)  # turns an array into a column vector
                O0y = O0['y'].reshape(-1, 1)
                
                if it == 0:
                    B0x = O0x
                    B0y = O0y

                # dfs
                if w2>0:
                    print("Measuring dispersion")
                    self.log("Measuring dispersion")
                    dP_P = self.interface.change_energy()
                    self.S.pull(self.interface)
                    self.interface.reset_energy()
                    O1 = self.S.get_orbit(bpms)
                    O1x = O1['x'].reshape(-1, 1)
                    O1y = O1['y'].reshape(-1, 1)
                    Dx = np.array([1e3 * dx * dP_P for dx in target_disp_x]).reshape(-1,1)
                    Dy = np.array([1e3 * dy * dP_P for dy in target_disp_y]).reshape(-1,1)
                    plt.clf()
                    plt.plot(Dx, label='nominal')
                else:
                    O1x=O1y=None
                    Dx=Dy=None

                # wfs
                if w3>0:
                    print("Measuring wakefield")
                    self.log("Measuring wakefield")
                    self.interface.change_intensity()
                    self.S.pull(self.interface)
                    self.interface.reset_intensity()
                    O2 = self.S.get_orbit(bpms)
                    O2x = O2['x'].reshape(-1, 1)
                    O2y = O2['y'].reshape(-1, 1)
                else:
                    O2x=O2y=None

                Bx=[]
                By=[]
                if w1>0:
                    Bx.append(wgt_orb*(O0x-B0x))
                    By.append(wgt_orb*(O0y-B0y))

                print(Bx[-1].shape)
                if w2>0 and O1x is not None:
                    plt.plot((O1x-O0x), label='measured')
                    plt.show()

                    Bx.append(wgt_dfs*((O1x-O0x) - Dx))
                    By.append(wgt_dfs*((O1y-O0y) - Dy))

                print(Bx[-1].shape)
                if w3>0 and O2x is not None:
                    By.append(wgt_wfs*(O2y-O0y))
                    Bx.append(wgt_wfs*(O2x-O0x))

                Bx=np.vstack(Bx)
                By=np.vstack(By)

                Axx[np.isnan(Axx)] = 0
                Ayy[np.isnan(Ayy)] = 0
                Axx[np.isnan(Bx.ravel()),:] =0
                Ayy[np.isnan(By.ravel()),:] = 0

                Bx[np.isnan(Bx)] = 0
                By[np.isnan(By)] = 0

                # A = U * Sigma * V^
                # A^+ = V * Sigma^+ * U^T

                filter_corr_x=np.all(np.isfinite(Axx),axis=0) #corrs
                filter_corr_y=np.all(np.isfinite(Ayy),axis=0)

                Axx=Axx[:,filter_corr_x]
                Ayy=Ayy[:,filter_corr_y]

                corrX = -gain * (np.linalg.pinv(Axx, rcond=rcond) @ Bx)  # theta = - gain * Axx^+ *Bx
                corrY = -gain * (np.linalg.pinv(Ayy, rcond=rcond) @ By)

                vals_x = [clamp(v,max_curr_h) for v in corrX.ravel()]
                vals_y = [clamp(v,max_curr_v) for v in corrY.ravel()] # flattens an array

                vals = np.array(vals_x + vals_y)
                self.interface.vary_correctors(Cx + Cy, vals)

                print(f'vals = {vals}')
                print(f'Cx = {Cx}')
                print(f'Cy = {Cy}')

                def filtering_norm_x(Ox,Bx):
                    Ox[np.isnan(Ox)] = 0
                    #Oy[np.isnan(Oy)] = 0
                    Bx[np.isnan(Bx)] = 0
                    #By[np.isnan(By)] = 0
                    return float(np.linalg.norm(Ox - Bx))

                def filtering_norm_y(Oy,By):
                    #Ox[np.isnan(Ox)] = 0
                    Oy[np.isnan(Oy)] = 0
                    #Bx[np.isnan(Bx)] = 0
                    By[np.isnan(By)] = 0
                    return float(np.linalg.norm(Oy - By))

                if w1>0:
                    self._hist_orbit_x.append(filtering_norm_x(O0x,B0x))
                    self._hist_orbit_y.append(filtering_norm_y(O0y,B0y))
                    self._hist_orbit.append(filtering_norm_x(O0x,B0x) + filtering_norm_y(O0y,B0y))

                if w2>0 and O1x is not None:
                    self._hist_disp_x.append(filtering_norm_x(O0x,O1x-Dx))
                    self._hist_disp_y.append(filtering_norm_y(O0y,O1y-Dy))
                    self._hist_disp.append(filtering_norm_x(O0x,O1x-Dx) + filtering_norm_y(O0y,O1y-Dy))

                if w3>0 and O2x is not None:
                    self._hist_wake_x.append(filtering_norm_x(O0x,O2x))
                    self._hist_wake_y.append(filtering_norm_y(O0y,O2y))
                    self._hist_wake.append(filtering_norm_x(O0x,O2x) + filtering_norm_y(O0y,O2y))

                self._plot_series(ax=self.traj_ax, canvas=self.traj_canvas, values_x=self._hist_orbit_x,values_y=self._hist_orbit_y, vals=self._hist_orbit, title=None,ylabel="[mm]")
                self._plot_series(ax=self.disp_ax,canvas= self.disp_canvas, values_x= self._hist_disp_x,values_y=self._hist_disp_y ,vals=self._hist_disp,title=None,ylabel="[mm]")
                self._plot_series(ax=self.wake_ax, canvas=self.wake_canvas, values_x=self._hist_wake_x, values_y=self._hist_wake_y ,vals=self._hist_wake,title=None,ylabel="[mm]")
                QApplication.processEvents()

            self.setWindowTitle("BBA_GUI")
            QMessageBox.information(self, "Correction", "Correction finished.")
            self.log("Correction finished.")
            self.save_session_settings(w1, w2, w3, rcond, iters, gain, Axx, Ayy, Bx, By)

        except Exception as e:
            self.setWindowTitle("BBA_GUI")
            QMessageBox.critical(self, "Correction error", str(e))
            self.log(f"Correction error: {e}")

    def _stop_correction(self):
        self._cancel = True
        QMessageBox.information(self, "Correction", "Stop requested. Finishing current iteration...")
        self.log("Stop requested. Finishing current iteration...")

    def _show_console_log(self):
        if self.log_console is None:
            self.log_console=LogConsole(self)
        self.log_console.show()
        self.log_console.raise_()
        self.log_console.activateWindow()

    def log(self,text):
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line=f"[{timestamp}] {text}"
        if self.log_console is None:
            self.log_console=LogConsole(self)
            self.log_console.show()
        self.log_console.log(line)

    def _clear_graphs(self):
        # it doesnt do fresh - start, it only clears the graphs
        self._cancel = True
        self._hist_orbit_x.clear(),self._hist_orbit_y.clear()
        self._hist_disp_x.clear(),self._hist_disp_y.clear()
        self._hist_wake_x.clear(),self._hist_wake_y.clear()
        self._hist_orbit.clear(),self._hist_disp.clear(),self._hist_wake.clear()
        self._plot_series(self.traj_ax, self.traj_canvas, values_x=[], values_y=[],vals=[],title=None,ylabel="[mm]")
        self._plot_series(self.disp_ax, self.disp_canvas, values_x=[],values_y=[],vals=[], title=None,ylabel="[mm]")
        self._plot_series(self.wake_ax, self.wake_canvas, values_x=[],values_y=[], vals=[],title=None,ylabel="[mm]")

    def handling(self, app_name,cwd=None, args=None):
        try:
            path = os.path.join(os.path.dirname(__file__), app_name)
            workdir=os.path.expanduser(os.path.expandvars(cwd))

            proc = QProcess(self)
            proc.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
            proc.setWorkingDirectory(workdir)

            env = QProcessEnvironment.systemEnvironment()
            proc.setProcessEnvironment(env)

            argv = [path] + (args or [])
            proc.start(sys.executable, argv)

            proc.readyReadStandardOutput.connect(
                lambda p=proc: print(bytes(p.readAllStandardOutput()).decode(errors="ignore"))
            )
            self._procs.append(proc)
            print(workdir)

        except Exception as e:
            self.log(f"Error: {e}")
            print(e)

    def _display_response_matrix(self):
        orbit_dir=self.trajectory_response_3.text()
        dispersion_dir=self.dfs_response_3.text()
        wakefield_dir=self.wfs_response_3.text()
        selected_mode=None

        for rb in self.radio_buttons:
            if rb.isChecked():
                selected_mode = rb.text()
                break

        if selected_mode is None:
            selected_mode = self.modes[0]

        if selected_mode==self.modes[0]:
            data_dir=orbit_dir
        elif selected_mode==self.modes[1]:
            data_dir=dispersion_dir
        elif selected_mode==self.modes[2]:
            data_dir=wakefield_dir
        self.handling('ComputeResponseMatrix_GUI.py', cwd=data_dir,args=[data_dir])

if __name__ == "__main__":
    app = QApplication(sys.argv)
    import SelectInterface
    dialog = SelectInterface.choose_acc_and_interface()
    if dialog is None:
        print("Selection cancelled.")
        sys.exit(1)

    I=dialog
    project_name=I.get_name()
    print(f"Selected interface: {project_name}")
    time_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    dir_name = f"~/flight-simulator-data/BBA_{I.get_name()}_{time_str}_session_settings"
    dir_name = os.path.expanduser(os.path.expandvars(dir_name))
    w = MainWindow(interface=I, dir_name=dir_name)

    if hasattr(I, "log_messages"):
        I.log_messages(w.log)

    w.show()
    sys.exit(app.exec())
